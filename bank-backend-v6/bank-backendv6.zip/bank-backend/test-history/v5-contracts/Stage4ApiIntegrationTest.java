package com.club.bank;
import com.fasterxml.jackson.databind.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import java.util.*;
import java.math.BigDecimal;
import java.util.concurrent.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

@SpringBootTest @AutoConfigureMockMvc
class Stage4ApiIntegrationTest {
    @Autowired MockMvc mvc;@Autowired ObjectMapper json;@Autowired JdbcTemplate jdbc;@Autowired FieldCrypto crypto;
    record Customer(String name,String token,String id,String number) {}
    String key(){return UUID.randomUUID().toString();}
    JsonNode call(MockHttpServletRequestBuilder r,int expected)throws Exception {
        var res=mvc.perform(r).andReturn().getResponse();assertEquals(expected,res.getStatus(),res.getContentAsString());
        return res.getContentAsByteArray().length==0?null:json.readTree(res.getContentAsByteArray());
    }
    MockHttpServletRequestBuilder body(MockHttpServletRequestBuilder r,Object value)throws Exception{return r.contentType(MediaType.APPLICATION_JSON).content(json.writeValueAsBytes(value));}
    MockHttpServletRequestBuilder auth(MockHttpServletRequestBuilder r,Customer c){return r.header("Authorization","Bearer "+c.token());}
    Customer customer()throws Exception{
        String name="t"+key().replace("-","").substring(0,15);var cred=Map.of("username",name,"password","LongPassword123!");
        call(body(post("/api/auth/register"),cred),201);String token=call(body(post("/api/v2/auth/login"),cred),200).path("token").asText();
        var a=call(post("/api/v2/accounts").header("Authorization","Bearer "+token).header("Idempotency-Key",key()),201);
        return new Customer(name,token,a.path("accountId").asText(),a.path("number").asText());
    }
    void deposit(Customer c,String amount)throws Exception{call(auth(body(post("/api/deposits"),Map.of("accountNumber",c.number(),"amount",amount)),c).header("Idempotency-Key",key()),200);}
    Map<String,Object> previewBody(Customer a,Customer b,Object amount){return Map.of("fromAccountId",a.id(),"bankCode","LOCAL","toAccountNumber",b.number(),"amount",amount,"memo","점심 정산");}
    JsonNode preview(Customer a,Customer b,String amount)throws Exception{return call(auth(body(post("/api/v2/transfers/previews"),previewBody(a,b,amount)),a),201);}
    String grant(Customer a,String id)throws Exception{return call(auth(body(post("/api/v2/auth/step-up"),Map.of("password","LongPassword123!","purpose","TRANSFER","targetId",id)),a),200).path("actionToken").asText();}
    MockHttpServletRequestBuilder execute(Customer a,String p,String token,String k)throws Exception{return auth(body(post("/api/v2/transfers"),Map.of("previewId",p,"actionToken",token)),a).header("Idempotency-Key",k);}
    String balance(Customer a)throws Exception{return call(auth(get("/api/v2/accounts/"+a.id()),a),200).path("balance").asText();}
    void legacy(Customer a,Customer b,String amount)throws Exception{call(auth(body(post("/api/transfers"),Map.of("fromAccount",a.number(),"toAccount",b.number(),"amount",amount)),a).header("Idempotency-Key",key()),200);}
    @Autowired org.springframework.security.crypto.password.PasswordEncoder encoder;
    JsonNode settings(Customer c)throws Exception{return call(auth(get("/api/v2/accounts/"+c.id()+"/preferences"),c),200);}
    JsonNode limits(Customer c)throws Exception{return call(auth(get("/api/v2/me/transfer-limits"),c),200);}
    String authorize(Customer c,String purpose,String target,Object changes)throws Exception{
        return call(auth(body(post("/api/v2/auth/step-up"),Map.of("password","LongPassword123!","purpose",purpose,"targetId",target,"changes",changes)),c),200).path("actionToken").asText();
    }
    JsonNode setPin(Customer c,String newPin)throws Exception{
        var changes=Map.of("version",settings(c).path("version").asLong(),"newPin",newPin);
        String token=authorize(c,"ACCOUNT_PIN",c.id(),changes);
        return call(auth(body(put("/api/v2/accounts/"+c.id()+"/pin"),Map.of("changes",changes,"actionToken",token)),c),200);
    }
    JsonNode setDebit(Customer c,boolean enabled)throws Exception{
        var changes=Map.of("version",settings(c).path("version").asLong(),"enabled",enabled);
        String token=authorize(c,"DEBIT_SETTING",c.id(),changes);
        return call(auth(body(put("/api/v2/accounts/"+c.id()+"/debit-setting"),Map.of("changes",changes,"actionToken",token)),c),200);
    }
    JsonNode setLimits(Customer c,String per,String daily)throws Exception{
        var old=limits(c);var changes=Map.of("version",old.path("version").asLong(),"perTransfer",per,"daily",daily);
        String token=authorize(c,"TRANSFER_LIMITS",old.path("customerId").asText(),changes);
        return call(auth(body(put("/api/v2/me/transfer-limits"),Map.of("changes",changes,"actionToken",token)),c),200);
    }
    MockHttpServletRequestBuilder pinStep(Customer a,String preview,String pin)throws Exception{
        return auth(body(post("/api/v2/auth/step-up"),Map.of("password","LongPassword123!","purpose","TRANSFER","targetId",preview,"pin",pin)),a);
    }
    @Test void preferencesEncryptAliasHideOnlyFromListsAndCheckVersions()throws Exception{
        Customer a=customer(),b=customer();deposit(a,"10");
        var changes=Map.of("version",0,"alias","생활비","hidden",true,"order",5);
        var r=call(auth(body(patch("/api/v2/accounts/"+a.id()+"/preferences"),changes),a),200);
        assertEquals("생활비",r.path("alias").asText());assertEquals(1,r.path("version").asLong());
        String stored=jdbc.queryForObject("SELECT alias_encrypted FROM accounts WHERE public_id=?",String.class,a.id());assertTrue(stored.startsWith("v1:"));assertFalse(stored.contains("생활비"));
        assertEquals(0,call(auth(get("/api/v2/accounts"),a),200).path("items").size());
        assertEquals(0,call(auth(get("/api/accounts"),a),200).size());
        assertEquals(1,call(auth(get("/api/v2/accounts").param("includeHidden","true"),a),200).path("items").size());
        assertEquals("10.00",balance(a)); // Hidden is display state, not authorization or withdrawal state.
        call(auth(body(patch("/api/v2/accounts/"+a.id()+"/preferences"),changes),b),404);
        call(auth(body(patch("/api/v2/accounts/"+a.id()+"/preferences"),changes),a),409);
        var update=call(auth(body(patch("/api/v2/accounts/"+a.id()+"/preferences"),Map.of("version",1,"hidden",false)),a),200);
        assertEquals("생활비",update.path("alias").asText());
        var clear=new HashMap<String,Object>();clear.put("version",2);clear.put("alias",null);
        assertTrue(call(auth(body(patch("/api/v2/accounts/"+a.id()+"/preferences"),clear),a),200).path("alias").isNull());
        call(auth(body(patch("/api/v2/accounts/"+a.id()+"/preferences"),Map.of("version",3,"order",-1)),a),400);
        assertEquals(3,settings(a).path("version").asLong());
        var extra=call(auth(post("/api/v2/accounts"),a).header("Idempotency-Key",key()),201);
        String extraId=extra.path("accountId").asText();
        assertEquals(extraId,call(auth(get("/api/v2/accounts"),a),200).path("items").get(0).path("accountId").asText());
    }
    @Test void favoritesArePrivateEncryptedUniqueVersionedAndDoNotBypassReceiverChecks()throws Exception{
        Customer a=customer(),b=customer(),other=customer();deposit(a,"10");
        var fields=Map.of("bankCode","LOCAL","accountNumber",b.number(),"alias","회비");
        var r=call(auth(body(post("/api/v2/beneficiaries"),fields),a),201);String id=r.path("id").asText();
        call(auth(body(post("/api/v2/beneficiaries"),fields),a),409);
        var stored=jdbc.queryForMap("SELECT number_encrypted,number_lookup,alias_encrypted FROM beneficiaries WHERE id=?",id);
        assertTrue(stored.get("NUMBER_ENCRYPTED").toString().startsWith("v1:"));assertFalse(stored.get("ALIAS_ENCRYPTED").toString().contains("회비"));
        assertEquals(0,call(auth(get("/api/v2/beneficiaries"),other),200).path("items").size());
        var second=call(auth(body(post("/api/v2/beneficiaries"),fields),other),201);
        assertNotEquals(stored.get("NUMBER_LOOKUP"),jdbc.queryForObject("SELECT number_lookup FROM beneficiaries WHERE id=?",String.class,second.path("id").asText()));
        call(auth(body(patch("/api/v2/beneficiaries/"+id),Map.of("version",0,"alias","바꿈")),other),404);
        call(auth(body(patch("/api/v2/beneficiaries/"+id),Map.of("version",0,"alias","바꿈")),a),200);
        call(auth(delete("/api/v2/beneficiaries/"+id).param("version","0"),a),409);
        jdbc.update("UPDATE accounts SET status='BLOCKED' WHERE public_id=?",b.id());
        call(auth(body(post("/api/v2/transfers/previews"),previewBody(a,b,"1")),a),409);
        call(auth(delete("/api/v2/beneficiaries/"+id).param("version","1"),a),204);
        assertEquals(0,call(auth(get("/api/v2/beneficiaries"),a),200).path("items").size());
    }
    @Test void debitSettingBlocksBothApisAndInvalidatesOldAuthorization()throws Exception{
        Customer a=customer(),b=customer();deposit(a,"100");String p=preview(a,b,"10").path("previewId").asText(),token=grant(a,p);
        setDebit(a,false);
        assertEquals("0.00",call(auth(get("/api/v2/accounts/"+a.id()),a),200).path("availableBalance").asText());
        assertEquals("DEBIT_DISABLED",call(execute(a,p,token,key()),409).path("code").asText());
        assertEquals("DEBIT_DISABLED",call(auth(body(post("/api/transfers"),Map.of("fromAccount",a.number(),"toAccount",b.number(),"amount","1")),a).header("Idempotency-Key",key()),409).path("code").asText());
        setDebit(a,true);
        assertEquals("ACTION_TOKEN_INVALID",call(execute(a,p,token,key()),403).path("code").asText());
        call(execute(a,p,grant(a,p),key()),200);assertEquals("90.00",balance(a));
    }
    @Test void configuredPinIsHashedRequiredForV2AndCannotBeBypassedThroughLegacy()throws Exception{
        Customer a=customer(),b=customer();deposit(a,"100");String p=preview(a,b,"10").path("previewId").asText(),old=grant(a,p);
        var settings=setPin(a,"4826");assertTrue(settings.path("pinConfigured").asBoolean());assertFalse(settings.has("pinHash"));
        String hash=jdbc.queryForObject("SELECT pin_hash FROM accounts WHERE public_id=?",String.class,a.id());assertTrue(encoder.matches("4826",hash));assertNotEquals("4826",hash);
        call(execute(a,p,old,key()),403);
        assertEquals("ACCOUNT_PIN_REQUIRED",call(auth(body(post("/api/transfers"),Map.of("fromAccount",a.number(),"toAccount",b.number(),"amount","1")),a).header("Idempotency-Key",key()),403).path("code").asText());
        call(auth(body(post("/api/v2/auth/step-up"),Map.of("password","LongPassword123!","purpose","TRANSFER","targetId",p)),a),403);
        assertEquals("PIN_INVALID",call(pinStep(a,p,"0000"),403).path("code").asText());
        assertEquals(1,jdbc.queryForObject("SELECT pin_failures FROM accounts WHERE public_id=?",Integer.class,a.id()));
        var granted=call(pinStep(a,p,"4826"),200);assertEquals("PASSWORD_AND_ACCOUNT_PIN",granted.path("authenticationMethod").asText());
        assertEquals(0,jdbc.queryForObject("SELECT pin_failures FROM accounts WHERE public_id=?",Integer.class,a.id()));
        String k=key();var done=call(execute(a,p,granted.path("actionToken").asText(),k),200);
        assertEquals(done,call(execute(a,p,granted.path("actionToken").asText(),k),200));assertEquals("90.00",balance(a));
    }
    @Test void concurrentWrongPinChangesPersistFailuresLockAndLeaveGrantUnconsumed()throws Exception{
        Customer a=customer();setPin(a,"4826");var changes=Map.of("version",1,"newPin","7391");String token=authorize(a,"ACCOUNT_PIN",a.id(),changes);
        var pool=Executors.newFixedThreadPool(5);var start=new CountDownLatch(1);var tasks=new ArrayList<Future<Integer>>();
        try{
            for(int i=0;i<5;i++)tasks.add(pool.submit(()->{start.await();return mvc.perform(auth(body(put("/api/v2/accounts/"+a.id()+"/pin"),Map.of("changes",changes,"actionToken",token,"currentPin","0000")),a)).andReturn().getResponse().getStatus();}));
            start.countDown();var statuses=new ArrayList<Integer>();for(var f:tasks)statuses.add(f.get(25,TimeUnit.SECONDS));
            assertEquals(4,Collections.frequency(statuses,403));assertEquals(1,Collections.frequency(statuses,423));
        }finally{pool.shutdownNow();}
        assertEquals(5,jdbc.queryForObject("SELECT pin_failures FROM accounts WHERE public_id=?",Integer.class,a.id()));
        assertTrue(settings(a).path("pinLocked").asBoolean());assertEquals(1,settings(a).path("version").asLong());
        assertFalse(jdbc.queryForObject("SELECT consumed FROM setting_actions WHERE token_hash=?",Boolean.class,SecurityConfig.hash(token)));
        call(auth(body(put("/api/v2/accounts/"+a.id()+"/pin"),Map.of("changes",changes,"actionToken",token,"currentPin","4826")),a),423);
        jdbc.update("UPDATE accounts SET pin_locked_until=? WHERE public_id=?",java.sql.Timestamp.from(java.time.Instant.now().minusSeconds(1)),a.id());
        var changed=call(auth(body(put("/api/v2/accounts/"+a.id()+"/pin"),Map.of("changes",changes,"actionToken",token,"currentPin","4826")),a),200);
        assertFalse(changed.path("pinLocked").asBoolean());assertEquals(2,changed.path("version").asLong());
        assertTrue(encoder.matches("7391",jdbc.queryForObject("SELECT pin_hash FROM accounts WHERE public_id=?",String.class,a.id())));
    }
    @Test void settingsTokensAreBoundToOwnerPurposeTargetValuesVersionAndExpiry()throws Exception{
        Customer a=customer(),b=customer();var changes=Map.of("version",0,"enabled",false);String token=authorize(a,"DEBIT_SETTING",a.id(),changes);
        call(auth(body(put("/api/v2/accounts/"+a.id()+"/debit-setting"),Map.of("changes",changes,"actionToken",token)),b),404);
        call(auth(body(put("/api/v2/accounts/"+b.id()+"/debit-setting"),Map.of("changes",changes,"actionToken",token)),b),403);
        call(auth(body(put("/api/v2/accounts/"+a.id()+"/debit-setting"),Map.of("changes",Map.of("version",0,"enabled",true),"actionToken",token)),a),403);
        call(auth(body(put("/api/v2/accounts/"+a.id()+"/pin"),Map.of("changes",Map.of("version",0,"newPin","1234"),"actionToken",token)),a),403);
        jdbc.update("UPDATE setting_actions SET expires_at=? WHERE token_hash=?",java.sql.Timestamp.from(java.time.Instant.now().minusSeconds(1)),SecurityConfig.hash(token));
        call(auth(body(put("/api/v2/accounts/"+a.id()+"/debit-setting"),Map.of("changes",changes,"actionToken",token)),a),403);
        token=authorize(a,"DEBIT_SETTING",a.id(),changes);
        call(auth(body(patch("/api/v2/accounts/"+a.id()+"/preferences"),Map.of("version",0,"alias","버전 변경")),a),200);
        call(auth(body(put("/api/v2/accounts/"+a.id()+"/debit-setting"),Map.of("changes",changes,"actionToken",token)),a),409);
        assertTrue(settings(a).path("debitEnabled").asBoolean());
    }
    @Test void dailyUsageIncludesBothApisAndAccountsButNotDepositsOrReplays()throws Exception{
        Customer a=customer(),b=customer();deposit(a,"200");assertEquals("1000000.00",limits(a).path("perTransfer").asText());
        setLimits(a,"70","100");String p=preview(a,b,"50").path("previewId").asText(),token=grant(a,p);
        legacy(a,b,"60");assertEquals("DAILY_LIMIT_EXCEEDED",call(execute(a,p,token,key()),409).path("code").asText());
        assertEquals("60.00",limits(a).path("usedToday").asText());deposit(a,"1");legacy(b,a,"10");
        assertEquals("60.00",limits(a).path("usedToday").asText());
        String next=preview(a,b,"20").path("previewId").asText(),nextToken=grant(a,next),k=key();
        call(execute(a,next,nextToken,k),200);call(execute(a,next,nextToken,k),200);
        assertEquals("80.00",limits(a).path("usedToday").asText());
        var extra=call(auth(post("/api/v2/accounts"),a).header("Idempotency-Key",key()),201);
        Customer own=new Customer(a.name(),a.token(),extra.path("accountId").asText(),extra.path("number").asText());deposit(own,"20");legacy(own,b,"10");
        assertEquals("90.00",limits(a).path("usedToday").asText());
        assertEquals("PER_TRANSFER_LIMIT_EXCEEDED",call(auth(body(post("/api/transfers"),Map.of("fromAccount",a.number(),"toAccount",b.number(),"amount","71")),a).header("Idempotency-Key",key()),409).path("code").asText());
        assertEquals("0.00",setLimits(a,"20","50").path("remainingDaily").asText());
        var l=limits(a);
        call(auth(body(post("/api/v2/auth/step-up"),Map.of("password","LongPassword123!","purpose","TRANSFER_LIMITS","targetId",l.path("customerId").asText(),"changes",Map.of("version",2,"perTransfer","21","daily","50"))),a),409);
        Long uid=jdbc.queryForObject("SELECT id FROM bank_users WHERE username_lookup=?",Long.class,crypto.lookup("bank_users.username",a.name()));
        var yesterday=AccountPolicy.today().minusDays(1);
        jdbc.update("UPDATE limit_usage SET id=?,usage_date=? WHERE user_id=? AND usage_date=?",uid+":"+yesterday,yesterday,uid,AccountPolicy.today());
        assertEquals("0.00",limits(a).path("usedToday").asText());legacy(a,b,"10");assertEquals("10.00",limits(a).path("usedToday").asText());
    }
    @Test void sharedDailyLimitRaceAllowsOnlyOnePosting()throws Exception{
        Customer a=customer(),b=customer();deposit(a,"200");setLimits(a,"100","100");
        String p1=preview(a,b,"80").path("previewId").asText(),p2=preview(a,b,"80").path("previewId").asText();
        String t1=grant(a,p1),t2=grant(a,p2);var pool=Executors.newFixedThreadPool(2);var start=new CountDownLatch(1);
        try{
            var f1=pool.submit(()->{start.await();return mvc.perform(execute(a,p1,t1,key())).andReturn().getResponse().getStatus();});
            var f2=pool.submit(()->{start.await();return mvc.perform(execute(a,p2,t2,key())).andReturn().getResponse().getStatus();});
            start.countDown();assertEquals(Set.of(200,409),Set.of(f1.get(20,TimeUnit.SECONDS),f2.get(20,TimeUnit.SECONDS)));
        }finally{pool.shutdownNow();}
        assertEquals("120.00",balance(a));assertEquals("80.00",balance(b));assertEquals("80.00",limits(a).path("usedToday").asText());
    }
    @Test void limitReductionAndTransferUseSameUserLock()throws Exception{
        Customer a=customer(),b=customer();deposit(a,"200");String p=preview(a,b,"80").path("previewId").asText(),token=grant(a,p);
        var old=limits(a);var changes=Map.of("version",0,"perTransfer","50","daily","50");String approval=authorize(a,"TRANSFER_LIMITS",old.path("customerId").asText(),changes);
        var pool=Executors.newFixedThreadPool(2);var start=new CountDownLatch(1);
        try{
            var f1=pool.submit(()->{start.await();return mvc.perform(execute(a,p,token,key())).andReturn().getResponse().getStatus();});
            var f2=pool.submit(()->{start.await();return call(auth(body(put("/api/v2/me/transfer-limits"),Map.of("changes",changes,"actionToken",approval)),a),200);});
            start.countDown();int status=f1.get(20,TimeUnit.SECONDS);f2.get(20,TimeUnit.SECONDS);assertTrue(status==200||status==409);
            assertEquals(status==200?"80.00":"0.00",limits(a).path("usedToday").asText());
            assertEquals(status==200?"120.00":"200.00",balance(a));
        }finally{pool.shutdownNow();}
        assertEquals("50.00",limits(a).path("daily").asText());
    }
    @Test void failedTransferRollsBackUsageAndGrantConsumption()throws Exception{
        Customer a=customer(),b=customer();deposit(a,"100");String p=preview(a,b,"13.37").path("previewId").asText(),token=grant(a,p),k=key();
        jdbc.execute("ALTER TABLE transfer_records ADD CONSTRAINT stage4_fail_record CHECK(preview_id <> '"+p+"')");
        try{call(execute(a,p,token,k),500);}finally{jdbc.execute("ALTER TABLE transfer_records DROP CONSTRAINT stage4_fail_record");}
        assertEquals("0.00",limits(a).path("usedToday").asText());assertEquals("100.00",balance(a));
        call(execute(a,p,token,k),200);assertEquals("13.37",limits(a).path("usedToday").asText());
    }
}
