package com.club.bank;
import com.fasterxml.jackson.databind.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import java.util.*;
import java.math.BigDecimal;
import java.util.concurrent.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

@SpringBootTest(properties={"spring.datasource.url=jdbc:h2:mem:stage5_demo;DB_CLOSE_DELAY=-1","bank.demo-inbox-key=fixture-demo-inbox-key-at-least-32-characters"}) @AutoConfigureMockMvc
@org.springframework.test.context.ActiveProfiles("demo-verification")
class Stage5ApiIntegrationTest {
    static final java.util.concurrent.atomic.AtomicInteger IPS=new java.util.concurrent.atomic.AtomicInteger();
    final String ip="192.0.2."+IPS.incrementAndGet();
    @Autowired MockMvc mvc;@Autowired ObjectMapper json;@Autowired JdbcTemplate jdbc;@Autowired FieldCrypto crypto;
    record Customer(String name,String token,String id,String number) {}
    String key(){return UUID.randomUUID().toString();}
    JsonNode call(MockHttpServletRequestBuilder r,int expected)throws Exception {
        var res=mvc.perform(r.with(req->{req.setRemoteAddr(ip);return req;})).andReturn().getResponse();assertEquals(expected,res.getStatus(),res.getContentAsString());
        return res.getContentAsByteArray().length==0?null:json.readTree(res.getContentAsByteArray());
    }
    MockHttpServletRequestBuilder body(MockHttpServletRequestBuilder r,Object value)throws Exception{return r.contentType(MediaType.APPLICATION_JSON).content(json.writeValueAsBytes(value));}
    MockHttpServletRequestBuilder auth(MockHttpServletRequestBuilder r,Customer c){return r.header("Authorization","Bearer "+c.token());}
    Customer customer()throws Exception{
        String name="t"+key().replace("-","").substring(0,15);var cred=Map.of("username",name,"password","LongPassword123!");
        call(body(post("/api/auth/register"),cred),201);String token=call(body(post("/api/v2/auth/login"),cred),200).path("token").asText();
        var a=call(post("/api/v2/accounts").header("Authorization","Bearer "+token).header("Idempotency-Key",key()),201);
        return new Customer(name,token,a.path("accountId").asText(),a.path("number").asText());
    }
    void deposit(Customer c,String amount)throws Exception{call(auth(body(post("/api/deposits"),Map.of("accountNumber",c.number(),"amount",amount)),c).header("Idempotency-Key",key()),200);}
    Map<String,Object> previewBody(Customer a,Customer b,Object amount){return Map.of("fromAccountId",a.id(),"bankCode","LOCAL","toAccountNumber",b.number(),"amount",amount,"memo","점심 정산");}
    JsonNode preview(Customer a,Customer b,String amount)throws Exception{return call(auth(body(post("/api/v2/transfers/previews"),previewBody(a,b,amount)),a),201);}
    String grant(Customer a,String id)throws Exception{return call(auth(body(post("/api/v2/auth/step-up"),Map.of("password","LongPassword123!","purpose","TRANSFER","targetId",id)),a),200).path("actionToken").asText();}
    MockHttpServletRequestBuilder execute(Customer a,String p,String token,String k)throws Exception{return auth(body(post("/api/v2/transfers"),Map.of("previewId",p,"actionToken",token)),a).header("Idempotency-Key",k);}
    String balance(Customer a)throws Exception{return call(auth(get("/api/v2/accounts/"+a.id()),a),200).path("balance").asText();}
    void legacy(Customer a,Customer b,String amount)throws Exception{call(auth(body(post("/api/transfers"),Map.of("fromAccount",a.number(),"toAccount",b.number(),"amount",amount)),a).header("Idempotency-Key",key()),200);}
    static final String INBOX="fixture-demo-inbox-key-at-least-32-characters";
    JsonNode challenge(String purpose,String channel,String contact,Customer c)throws Exception{
        var r=body(post("/api/v2/contact-challenges"),Map.of("purpose",purpose,"channel",channel,"contact",contact));
        return call(c==null?r:auth(r,c),202);
    }
    String inbox(JsonNode c)throws Exception{return call(body(post("/api/v2/demo/inbox"),Map.of("challengeId",c.path("challengeId").asText(),"inboxToken",c.path("inboxToken").asText())).header("X-Demo-Inbox-Key",INBOX),200).path("code").asText();}
    String verify(JsonNode c,String code,Customer user)throws Exception{
        var r=body(post("/api/v2/contact-challenges/"+c.path("challengeId").asText()+"/verify"),Map.of("code",code));
        return call(user==null?r:auth(r,user),200).path("contactGrant").asText();
    }
    List<String> codes(Customer c)throws Exception{
        var r=call(auth(body(post("/api/v2/me/recovery-codes"),Map.of("currentPassword","LongPassword123!")),c),200);
        List<String> values=new ArrayList<>();r.path("codes").forEach(x->values.add(x.asText()));return values;
    }
    Long uid(Customer c){return jdbc.queryForObject("SELECT id FROM bank_users WHERE username_lookup=?",Long.class,crypto.lookup("bank_users.username",c.name()));}
    @Test void registrationRecordsTermsAndMockContactWithStableIdempotency()throws Exception{
        String email="test"+key()+"@example.com";var c=challenge("REGISTER","EMAIL",email,null);
        assertFalse(c.has("code"));String raw=inbox(c);String grant=verify(c,raw,null);
        var stored=jdbc.queryForMap("SELECT code_hash,code_encrypted,contact_encrypted,grant_hash FROM contact_challenges WHERE id=?",c.path("challengeId").asText());
        assertNotEquals(raw,stored.get("CODE_HASH"));assertNull(stored.get("CODE_ENCRYPTED"));assertFalse(stored.get("CONTACT_ENCRYPTED").toString().contains(email));assertEquals(SecurityConfig.hash(grant),stored.get("GRANT_HASH"));
        String name="u"+key().replace("-","").substring(0,15);var req=new HashMap<String,Object>();
        req.put("username",name);req.put("password","LongPassword123!");req.put("name","김영우");req.put("termsVersions",IdentityService.TERMS);req.put("contactGrant",grant);
        String k=key();var first=call(body(post("/api/v2/auth/register"),req).header("Idempotency-Key",k),201);
        assertEquals(first,call(body(post("/api/v2/auth/register"),req).header("Idempotency-Key",k),201));
        req.put("name","다른 이름");call(body(post("/api/v2/auth/register"),req).header("Idempotency-Key",k),409);
        String token=call(body(post("/api/v2/auth/login"),Map.of("username",name,"password","LongPassword123!")),200).path("token").asText();
        Customer user=new Customer(name,token,"","");var me=call(auth(get("/api/v2/auth/me"),user),200);
        assertEquals(email,me.path("email").asText());assertFalse(me.path("emailVerified").asBoolean());assertEquals("SIMULATED",me.path("emailAssurance").asText());
        assertEquals(2,call(auth(get("/api/v2/me/terms"),user),200).path("items").size());assertEquals(2,call(get("/api/v2/terms"),200).path("items").size());
        req.put("username","u"+key().replace("-","").substring(0,15));call(body(post("/api/v2/auth/register"),req).header("Idempotency-Key",key()),403);
        req.remove("contactGrant");req.put("termsVersions",Map.of());call(body(post("/api/v2/auth/register"),req).header("Idempotency-Key",key()),409);
        req.put("termsVersions",IdentityService.TERMS);call(body(post("/api/v2/auth/register"),req).header("Idempotency-Key",key()),201);
    }
    @Test void inboxOwnershipChallengeExpiryFailureLimitAndResendInvalidation()throws Exception{
        var c=challenge("REGISTER","EMAIL","a"+key()+"@example.com",null);String id=c.path("challengeId").asText(),right=inbox(c);
        var req=Map.of("challengeId",id,"inboxToken",c.path("inboxToken").asText());call(body(post("/api/v2/demo/inbox"),req),403);
        call(body(post("/api/v2/demo/inbox"),Map.of("challengeId",id,"inboxToken","bad")).header("X-Demo-Inbox-Key",INBOX),404);
        String wrong=right.equals("000000")?"000001":"000000";
        for(int i=0;i<5;i++)call(body(post("/api/v2/contact-challenges/"+id+"/verify"),Map.of("code",wrong)),400);
        assertEquals(5,jdbc.queryForObject("SELECT failures FROM contact_challenges WHERE id=?",Integer.class,id));
        call(body(post("/api/v2/contact-challenges/"+id+"/verify"),Map.of("code",right)),400);
        String mail="b"+key()+"@example.com";var old=challenge("REGISTER","EMAIL",mail,null);String oldCode=inbox(old);
        call(body(post("/api/v2/contact-challenges"),Map.of("purpose","REGISTER","channel","EMAIL","contact",mail)),429);
        jdbc.update("UPDATE identity_rates SET until=?",java.sql.Timestamp.from(java.time.Instant.now().minusSeconds(1)));
        var newer=challenge("REGISTER","EMAIL",mail,null);call(body(post("/api/v2/contact-challenges/"+old.path("challengeId").asText()+"/verify"),Map.of("code",oldCode)),400);
        String newCode=inbox(newer);jdbc.update("UPDATE contact_challenges SET expires_at=? WHERE id=?",java.sql.Timestamp.from(java.time.Instant.now().minusSeconds(1)),newer.path("challengeId").asText());
        call(body(post("/api/v2/contact-challenges/"+newer.path("challengeId").asText()+"/verify"),Map.of("code",newCode)),400);
    }
    @Test void profileGrantIsUserBoundAndProfileEditsClearSimulatedAssurance()throws Exception{
        Customer a=customer(),b=customer();var c=challenge("PROFILE","SMS","010-1234-5678",a);String code=inbox(c);
        call(auth(body(post("/api/v2/contact-challenges/"+c.path("challengeId").asText()+"/verify"),Map.of("code",code)),b),404);
        String grant=verify(c,code,a);var fields=Map.of("currentPassword","LongPassword123!","contactGrant",grant);
        call(auth(body(put("/api/v2/me/contact"),fields),b),403);call(auth(body(put("/api/v2/me/contact"),fields),a),204);
        var me=call(auth(get("/api/v2/auth/me"),a),200);assertEquals("+821012345678",me.path("phone").asText());assertEquals("SIMULATED",me.path("phoneAssurance").asText());assertFalse(me.path("phoneVerified").asBoolean());
        call(auth(body(put("/api/v2/me/contact"),fields),a),403);
        var updated=call(auth(body(put("/api/v2/me/profile"),Map.of("currentPassword","LongPassword123!","version",me.path("version").asLong(),"phone","01099998888")),a),200);
        assertEquals("UNVERIFIED",updated.path("phoneAssurance").asText());
    }
    @Test void recoveryCodesAreOneTimeHashedRotatedAndAllowUsernameRecovery()throws Exception{
        Customer a=customer();var first=codes(a);assertEquals(5,new HashSet<>(first).size());
        assertEquals(1,jdbc.queryForObject("SELECT COUNT(*) FROM recovery_codes WHERE code_hash=?",Integer.class,SecurityConfig.hash(first.get(0))));
        assertEquals(a.name(),call(body(post("/api/v2/recovery/username"),Map.of("recoveryCode",first.get(0))),200).path("username").asText());
        call(body(post("/api/v2/recovery/username"),Map.of("recoveryCode",first.get(0))),400);
        assertEquals(4,call(auth(get("/api/v2/me/recovery-codes"),a),200).path("remaining").asInt());
        var second=codes(a);call(body(post("/api/v2/recovery/username"),Map.of("recoveryCode",first.get(1))),400);assertEquals(5,second.size());
        call(auth(body(post("/api/v2/me/recovery-codes"),Map.of("currentPassword","bad")),a),401);
    }
    @Test void passwordRecoveryRevokesAllSessionsActionsAndCodes()throws Exception{
        Customer a=customer(),b=customer();deposit(a,"100");String p=preview(a,b,"10").path("previewId").asText(),approval=grant(a,p);var raw=codes(a);
        String second=call(body(post("/api/v2/auth/login"),Map.of("username",a.name(),"password","LongPassword123!")),200).path("token").asText();
        call(body(post("/api/v2/recovery/password"),Map.of("username",b.name(),"recoveryCode",raw.get(0),"newPassword","ChangedPassword456!")),400);
        call(body(post("/api/v2/recovery/password"),Map.of("username",a.name(),"recoveryCode",raw.get(0),"newPassword","ChangedPassword456!")),204);
        call(auth(get("/api/v2/auth/me"),a),401);call(get("/api/v2/auth/me").header("Authorization","Bearer "+second),401);
        call(body(post("/api/v2/auth/login"),Map.of("username",a.name(),"password","LongPassword123!")),401);
        String token=call(body(post("/api/v2/auth/login"),Map.of("username",a.name(),"password","ChangedPassword456!")),200).path("token").asText();
        Customer fresh=new Customer(a.name(),token,a.id(),a.number());call(execute(fresh,p,approval,key()),403);
        assertEquals(0,jdbc.queryForObject("SELECT COUNT(*) FROM recovery_codes WHERE user_id=?",Integer.class,uid(a)));
        call(body(post("/api/v2/recovery/username"),Map.of("recoveryCode",raw.get(1))),400);
        assertEquals("100.00",balance(fresh));
    }
    @Test void passwordChangeRequiresOldPasswordAndInvalidatesCurrentToken()throws Exception{
        Customer a=customer();codes(a);
        call(auth(body(put("/api/v2/me/password"),Map.of("currentPassword","bad","newPassword","ChangedPassword456!")),a),401);
        call(auth(body(put("/api/v2/me/password"),Map.of("currentPassword","LongPassword123!","newPassword","ChangedPassword456!")),a),204);
        call(auth(get("/api/v2/auth/me"),a),401);assertEquals(0,jdbc.queryForObject("SELECT COUNT(*) FROM recovery_codes WHERE user_id=?",Integer.class,uid(a)));
    }
    @Test void pinResetNeedsPasswordAndOwnRecoveryCodeAndClearsLock()throws Exception{
        Customer a=customer(),b=customer();var raw=codes(a);var other=codes(b);
        jdbc.update("UPDATE accounts SET pin_hash=?,pin_failures=5,pin_locked_until=? WHERE public_id=?","unused",java.sql.Timestamp.from(java.time.Instant.now().plusSeconds(900)),a.id());
        call(auth(body(post("/api/v2/accounts/"+a.id()+"/pin/reset"),Map.of("currentPassword","LongPassword123!","recoveryCode",other.get(0),"newPin","7391")),a),400);
        call(auth(body(post("/api/v2/accounts/"+b.id()+"/pin/reset"),Map.of("currentPassword","LongPassword123!","recoveryCode",raw.get(0),"newPin","7391")),a),404);
        call(auth(body(post("/api/v2/accounts/"+a.id()+"/pin/reset"),Map.of("currentPassword","LongPassword123!","recoveryCode",raw.get(0),"newPin","7391")),a),204);
        call(auth(get("/api/v2/auth/me"),a),401);assertEquals(0,jdbc.queryForObject("SELECT pin_failures FROM accounts WHERE public_id=?",Integer.class,a.id()));
        assertNull(jdbc.queryForObject("SELECT pin_locked_until FROM accounts WHERE public_id=?",java.sql.Timestamp.class,a.id()));
    }
    @Test void concurrentRecoveryCodeUseAndLoginResetAreSerialized()throws Exception{
        Customer a=customer();String raw=codes(a).get(0);var pool=Executors.newFixedThreadPool(2);var start=new CountDownLatch(1);
        try{
            var f1=pool.submit(()->{start.await();return mvc.perform(body(post("/api/v2/recovery/password"),Map.of("username",a.name(),"recoveryCode",raw,"newPassword","ChangedPassword456!"))).andReturn().getResponse().getStatus();});
            var f2=pool.submit(()->{start.await();return mvc.perform(body(post("/api/v2/recovery/password"),Map.of("username",a.name(),"recoveryCode",raw,"newPassword","ChangedPassword456!"))).andReturn().getResponse().getStatus();});
            start.countDown();assertEquals(Set.of(204,400),Set.of(f1.get(20,TimeUnit.SECONDS),f2.get(20,TimeUnit.SECONDS)));
        }finally{pool.shutdownNow();}
        call(auth(get("/api/v2/auth/me"),a),401);
        Customer b=customer();String code=codes(b).get(0);var concurrent=Executors.newFixedThreadPool(2);var go=new CountDownLatch(1);
        try{
            var login=concurrent.submit(()->{go.await();return mvc.perform(body(post("/api/v2/auth/login"),Map.of("username",b.name(),"password","LongPassword123!"))).andReturn().getResponse();});
            var reset=concurrent.submit(()->{go.await();return call(body(post("/api/v2/recovery/password"),Map.of("username",b.name(),"recoveryCode",code,"newPassword","ChangedPassword456!")),204);});
            go.countDown();var response=login.get(20,TimeUnit.SECONDS);reset.get(20,TimeUnit.SECONDS);
            if(response.getStatus()==200){String issued=json.readTree(response.getContentAsByteArray()).path("token").asText();call(get("/api/v2/auth/me").header("Authorization","Bearer "+issued),401);}else assertEquals(401,response.getStatus());
        }finally{concurrent.shutdownNow();}
    }
}
