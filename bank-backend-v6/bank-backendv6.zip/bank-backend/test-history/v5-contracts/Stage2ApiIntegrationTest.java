package com.club.bank;
import com.fasterxml.jackson.databind.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import java.util.*;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

@SpringBootTest @AutoConfigureMockMvc
class Stage2ApiIntegrationTest {
    @Autowired MockMvc mvc;@Autowired ObjectMapper json;@Autowired JdbcTemplate jdbc;@Autowired FieldCrypto crypto;
    record Customer(String name,String token,String id,String number) {}
    String key(){return UUID.randomUUID().toString();}
    JsonNode call(MockHttpServletRequestBuilder r,int expected) throws Exception {
        var res=mvc.perform(r).andReturn().getResponse();
        assertEquals(expected,res.getStatus(),res.getContentAsString());
        return res.getContentAsByteArray().length==0?null:json.readTree(res.getContentAsByteArray());
    }
    MockHttpServletRequestBuilder body(MockHttpServletRequestBuilder r,Object value)throws Exception {
        return r.contentType(MediaType.APPLICATION_JSON).content(json.writeValueAsBytes(value));
    }
    MockHttpServletRequestBuilder auth(MockHttpServletRequestBuilder r,Customer c){return r.header("Authorization","Bearer "+c.token());}
    Customer customer() throws Exception {
        String name="s"+key().replace("-","").substring(0,15);
        Map<String,String> credentials=Map.of("username",name,"password","LongPassword123!");
        call(body(post("/api/auth/register"),credentials),201);
        String token=call(body(post("/api/v2/auth/login"),credentials),200).path("token").asText();
        var opened=call(post("/api/v2/accounts").header("Authorization","Bearer "+token).header("Idempotency-Key",key()),201);
        return new Customer(name,token,opened.path("accountId").asText(),opened.path("number").asText());
    }
    JsonNode deposit(Customer c,String amount)throws Exception {
        return call(auth(body(post("/api/deposits"),Map.of("accountNumber",c.number(),"amount",new BigDecimal(amount))),c).header("Idempotency-Key",key()),200);
    }
    @Test void meAndLogoutRevokeOnlyCurrentToken()throws Exception {
        Customer c=customer();
        var me=call(auth(get("/api/v2/auth/me"),c),200);assertEquals(c.name(),me.path("username").asText());
        assertTrue(me.path("name").isNull());assertFalse(me.has("passwordHash"));
        String second=call(body(post("/api/v2/auth/login"),Map.of("username",c.name(),"password","LongPassword123!")),200).path("token").asText();
        call(auth(post("/api/v2/auth/logout"),c),204);
        call(auth(get("/api/v2/auth/me"),c),401);call(auth(get("/api/accounts"),c),401);
        call(auth(post("/api/v2/auth/logout"),c),401);
        call(get("/api/v2/auth/me").header("Authorization","Bearer "+second),200);
        call(get("/api/v2/accounts"),401);
    }
    @Test void profileIsEncryptedUnverifiedVersionedAndPrivate()throws Exception {
        Customer c=customer(),other=customer();
        var fields=new HashMap<String,Object>();fields.put("currentPassword","LongPassword123!");fields.put("version",0);
        fields.put("name","김영우");fields.put("email","Young@EXAMPLE.COM");fields.put("phone","010-1234-5678");
        var updated=call(auth(body(put("/api/v2/me/profile"),fields),c),200);
        assertEquals("Young@example.com",updated.path("email").asText());assertEquals("+821012345678",updated.path("phone").asText());
        assertFalse(updated.path("emailVerified").asBoolean());assertFalse(updated.path("phoneVerified").asBoolean());
        assertEquals(1,updated.path("version").asLong());
        var stored=jdbc.queryForMap("SELECT name_encrypted,email_encrypted,email_lookup,phone_encrypted,phone_lookup FROM bank_users WHERE username_lookup=?",crypto.lookup("bank_users.username",c.name()));
        assertNotEquals("김영우",stored.get("NAME_ENCRYPTED"));
        assertEquals(crypto.lookup("bank_users.email","Young@example.com"),stored.get("EMAIL_LOOKUP"));
        assertEquals(crypto.lookup("bank_users.phone","+821012345678"),stored.get("PHONE_LOOKUP"));
        assertTrue(call(auth(get("/api/v2/auth/me"),other),200).path("email").isNull());
        assertEquals("PROFILE_VERSION_CONFLICT",call(auth(body(put("/api/v2/me/profile"),fields),c),409).path("code").asText());
        fields.put("version",1);fields.put("currentPassword","wrong");call(auth(body(put("/api/v2/me/profile"),fields),c),401);
        fields.put("currentPassword","LongPassword123!");fields.put("phone","bad");call(auth(body(put("/api/v2/me/profile"),fields),c),400);
        fields.put("name",null);fields.put("email",null);fields.put("phone",null);
        assertTrue(call(auth(body(put("/api/v2/me/profile"),fields),c),200).path("email").isNull());
    }
    @Test void accountsUseUuidStringMoneyAndStableOpeningReplay()throws Exception {
        Customer c=customer(),other=customer();
        var items=call(auth(get("/api/v2/accounts"),c),200).path("items");assertEquals(1,items.size());
        var detail=call(auth(get("/api/v2/accounts/"+c.id()),c),200);
        assertEquals("0.00",detail.path("balance").asText());assertTrue(detail.path("balance").isTextual());
        assertEquals("KRW",detail.path("currency").asText());assertFalse(detail.path("openedAt").isNull());
        call(auth(get("/api/v2/accounts/"+other.id()),c),404);
        call(auth(get("/api/v2/accounts/"+other.id()+"/transactions"),c),404);
        call(auth(get("/api/v2/accounts/not-uuid"),c),400);
        call(auth(get("/api/v2/accounts/"+key()),c),404);
        call(auth(post("/api/v2/accounts"),c),400);
        String k=key();var first=call(auth(post("/api/v2/accounts"),c).header("Idempotency-Key",k),201);
        Customer extra=new Customer(c.name(),c.token(),first.path("accountId").asText(),first.path("number").asText());deposit(extra,"99999999999999999.99");
        assertEquals(first,call(auth(post("/api/v2/accounts"),c).header("Idempotency-Key",k),201));
        assertEquals("99999999999999999.99",call(auth(get("/api/v2/accounts/"+extra.id()),c),200).path("balance").asText());
        assertTrue(call(auth(get("/api/accounts/"+extra.number()+"/balance"),c),200).path("balance").isNumber());
        call(auth(body(post("/api/deposits"),Map.of("accountNumber",c.number(),"amount",1)),c).header("Idempotency-Key",k),409);
    }
    @Test void transactionPagesHonorKoreanBoundariesTiesFiltersAndCursorScope()throws Exception {
        Customer c=customer(),other=customer();
        String[] times={"2026-10-01T14:59:59.999999Z","2026-10-01T15:00:00Z","2026-10-01T15:00:00Z","2026-10-02T14:59:59.999999Z","2026-10-02T15:00:00Z"};
        for(String t:times){String id=deposit(c,"1").path("depositId").asText();jdbc.update("UPDATE ledger_entries SET created_at=? WHERE transfer_id=?",java.sql.Timestamp.from(java.time.Instant.parse(t)),id);}
        String path="/api/v2/accounts/"+c.id()+"/transactions";
        var first=call(auth(get(path).param("from","2026-10-02").param("to","2026-10-02").param("size","2"),c),200);
        assertTrue(first.path("hasNext").asBoolean());assertEquals(2,first.path("items").size());
        String cursor=first.path("nextCursor").asText();
        String late=deposit(c,"1").path("depositId").asText();jdbc.update("UPDATE ledger_entries SET created_at=? WHERE transfer_id=?",java.sql.Timestamp.from(java.time.Instant.parse(times[1])),late);
        var second=call(auth(get(path).param("from","2026-10-02").param("to","2026-10-02").param("size","2").param("cursor",cursor),c),200);
        assertEquals(1,second.path("items").size());assertFalse(second.path("hasNext").asBoolean());assertTrue(second.path("nextCursor").isNull());
        Set<String> ids=new HashSet<>();for(var i:first.path("items"))ids.add(i.path("entryId").asText());
        assertTrue(ids.add(second.path("items").get(0).path("entryId").asText()));
        call(auth(get(path).param("from","2026-10-02").param("to","2026-10-02").param("cursor",cursor+"x"),c),400);
        call(auth(get(path).param("from","2026-10-02").param("to","2026-10-02").param("type","DEPOSIT").param("cursor",cursor),c),400);
        call(auth(get("/api/v2/accounts/"+other.id()+"/transactions").param("from","2026-10-02").param("to","2026-10-02").param("cursor",cursor),other),400);
        var withdrawals=call(auth(get(path).param("from","2026-10-02").param("to","2026-10-02").param("type","WITHDRAWAL"),c),200);
        assertEquals(0,withdrawals.path("items").size());
        call(auth(get(path).param("to","+999999999-01-01"),c),400);
        call(auth(get(path).param("size","101"),c),400);call(auth(get(path).param("size","0"),c),400);
        call(auth(get(path).param("type","OTHER"),c),400);call(auth(get(path).param("from","invalid"),c),400);
        call(auth(get(path).param("from","2026-10-03").param("to","2026-10-02"),c),400);
        call(auth(get(path).param("from","2024-10-02").param("to","2026-10-02"),c),400);
    }
    @Test void newLedgerStoresBalancesForBothSidesOfLegacyTransfer()throws Exception {
        Customer a=customer(),b=customer();deposit(a,"10");
        call(auth(body(post("/api/transfers"),Map.of("fromAccount",a.number(),"toAccount",b.number(),"amount",new BigDecimal("3"))),a).header("Idempotency-Key",key()),200);
        var outgoing=call(auth(get("/api/v2/accounts/"+a.id()+"/transactions").param("type","WITHDRAWAL"),a),200).path("items").get(0);
        var incoming=call(auth(get("/api/v2/accounts/"+b.id()+"/transactions").param("type","DEPOSIT"),b),200).path("items").get(0);
        assertEquals("-3.00",outgoing.path("amount").asText());assertEquals("7.00",outgoing.path("balanceAfter").asText());
        assertEquals("3.00",incoming.path("amount").asText());assertEquals("3.00",incoming.path("balanceAfter").asText());
        assertEquals(outgoing.path("transferId"),incoming.path("transferId"));
    }
}
