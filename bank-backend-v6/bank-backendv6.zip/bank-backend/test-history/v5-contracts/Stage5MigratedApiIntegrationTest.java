package com.club.bank;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
@SpringBootTest(properties={"spring.datasource.url=jdbc:h2:mem:stage5_migrated;MODE=PostgreSQL;DB_CLOSE_DELAY=-1","spring.flyway.enabled=true","spring.jpa.hibernate.ddl-auto=validate","bank.demo-inbox-key=fixture-demo-inbox-key-at-least-32-characters"})
@AutoConfigureMockMvc @org.springframework.test.context.ActiveProfiles("demo-verification")
class Stage5MigratedApiIntegrationTest extends Stage5ApiIntegrationTest {}
