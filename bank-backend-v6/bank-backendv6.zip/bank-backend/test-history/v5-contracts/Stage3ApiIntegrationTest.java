package com.club.bank;
import com.fasterxml.jackson.databind.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import java.util.*;
import java.math.BigDecimal;
import java.util.concurrent.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

@SpringBootTest @AutoConfigureMockMvc
class Stage3ApiIntegrationTest {
    @Autowired MockMvc mvc;@Autowired ObjectMapper json;@Autowired JdbcTemplate jdbc;@Autowired FieldCrypto crypto;
    record Customer(String name,String token,String id,String number) {}
    String key(){return UUID.randomUUID().toString();}
    JsonNode call(MockHttpServletRequestBuilder r,int expected)throws Exception {
        var res=mvc.perform(r).andReturn().getResponse();assertEquals(expected,res.getStatus(),res.getContentAsString());
        return res.getContentAsByteArray().length==0?null:json.readTree(res.getContentAsByteArray());
    }
    MockHttpServletRequestBuilder body(MockHttpServletRequestBuilder r,Object value)throws Exception{return r.contentType(MediaType.APPLICATION_JSON).content(json.writeValueAsBytes(value));}
    MockHttpServletRequestBuilder auth(MockHttpServletRequestBuilder r,Customer c){return r.header("Authorization","Bearer "+c.token());}
    Customer customer()throws Exception{
        String name="t"+key().replace("-","").substring(0,15);var cred=Map.of("username",name,"password","LongPassword123!");
        call(body(post("/api/auth/register"),cred),201);String token=call(body(post("/api/v2/auth/login"),cred),200).path("token").asText();
        var a=call(post("/api/v2/accounts").header("Authorization","Bearer "+token).header("Idempotency-Key",key()),201);
        return new Customer(name,token,a.path("accountId").asText(),a.path("number").asText());
    }
    void deposit(Customer c,String amount)throws Exception{call(auth(body(post("/api/deposits"),Map.of("accountNumber",c.number(),"amount",amount)),c).header("Idempotency-Key",key()),200);}
    Map<String,Object> previewBody(Customer a,Customer b,Object amount){return Map.of("fromAccountId",a.id(),"bankCode","LOCAL","toAccountNumber",b.number(),"amount",amount,"memo","점심 정산");}
    JsonNode preview(Customer a,Customer b,String amount)throws Exception{return call(auth(body(post("/api/v2/transfers/previews"),previewBody(a,b,amount)),a),201);}
    String grant(Customer a,String id)throws Exception{return call(auth(body(post("/api/v2/auth/step-up"),Map.of("password","LongPassword123!","purpose","TRANSFER","targetId",id)),a),200).path("actionToken").asText();}
    MockHttpServletRequestBuilder execute(Customer a,String p,String token,String k)throws Exception{return auth(body(post("/api/v2/transfers"),Map.of("previewId",p,"actionToken",token)),a).header("Idempotency-Key",k);}
    String balance(Customer a)throws Exception{return call(auth(get("/api/v2/accounts/"+a.id()),a),200).path("balance").asText();}
    void legacy(Customer a,Customer b,String amount)throws Exception{call(auth(body(post("/api/transfers"),Map.of("fromAccount",a.number(),"toAccount",b.number(),"amount",amount)),a).header("Idempotency-Key",key()),200);}
    @Test void fullFlowEncryptsSnapshotsHashesGrantsAndReplaysAfterExpiry()throws Exception{
        Customer a=customer(),b=customer();deposit(a,"100");
        call(auth(body(put("/api/v2/me/profile"),Map.of("currentPassword","LongPassword123!","version",0,"name","김영우")),b),200);
        var receiver=call(auth(body(post("/api/v2/transfers/receiver-validation"),Map.of("bankCode","LOCAL","accountNumber",b.number())),a),200);
        assertEquals("김**",receiver.path("receiverName").asText());assertFalse(receiver.path("nameVerified").asBoolean());assertFalse(receiver.toString().contains(b.name()));
        var p=preview(a,b,"30");String id=p.path("previewId").asText();assertEquals("100.00",balance(a));
        String token=grant(a,id),k=key();
        assertEquals(1,jdbc.queryForObject("SELECT COUNT(*) FROM transfer_actions WHERE token_hash=?",Integer.class,SecurityConfig.hash(token)));
        String encrypted=jdbc.queryForObject("SELECT snapshot_encrypted FROM transfer_previews WHERE id=?",String.class,id);
        assertTrue(encrypted.startsWith("v1:"));assertFalse(encrypted.contains(b.number()));assertFalse(encrypted.contains("점심"));
        var result=call(execute(a,id,token,k),200);String transfer=result.path("transferId").asText();
        assertEquals("30.00",result.path("amount").asText());assertEquals("70.00",result.path("balanceAfter").asText());
        assertEquals("70.00",balance(a));assertEquals("30.00",balance(b));
        assertEquals(2,jdbc.queryForObject("SELECT COUNT(*) FROM ledger_entries WHERE transfer_id=?",Integer.class,transfer));
        assertEquals(1,jdbc.queryForObject("SELECT COUNT(*) FROM transfer_actions WHERE token_hash=? AND consumed=TRUE",Integer.class,SecurityConfig.hash(token)));
        jdbc.update("UPDATE transfer_previews SET expires_at=TIMESTAMP '2000-01-01 00:00:00' WHERE id=?",id);
        jdbc.update("UPDATE transfer_actions SET expires_at=TIMESTAMP '2000-01-01 00:00:00' WHERE token_hash=?",SecurityConfig.hash(token));
        deposit(a,"1");assertEquals(result,call(execute(a,id,token,k),200));assertEquals(result,call(auth(get("/api/v2/transfers/"+transfer),a),200));
        assertEquals("PREVIEW_ALREADY_USED",call(execute(a,id,token,key()),409).path("code").asText());
        assertEquals("IDEMPOTENCY_KEY_CONFLICT",call(execute(a,id,"different",k),409).path("code").asText());
        call(auth(get("/api/v2/transfers/"+transfer),b),404);
        assertEquals(0,call(auth(get("/api/v2/transfers"),b),200).path("items").size());
    }
    @Test void validatesOwnershipInputsPurposeAndTokenBinding()throws Exception{
        Customer a=customer(),b=customer();deposit(a,"100");deposit(b,"100");
        call(auth(body(post("/api/v2/transfers/previews"),previewBody(b,a,"1")),a),404);
        call(auth(body(post("/api/v2/transfers/previews"),previewBody(a,a,"1")),a),400);
        for(Object amount:List.of("0","-1","1.001","1e2","01","100000000000000000",3))
            call(auth(body(post("/api/v2/transfers/previews"),previewBody(a,b,amount)),a),400);
        call(auth(body(post("/api/v2/transfers/receiver-validation"),Map.of("bankCode","004","accountNumber",b.number())),a),400);
        String p=preview(a,b,"1").path("previewId").asText(),other=preview(a,b,"2").path("previewId").asText();
        call(auth(body(post("/api/v2/auth/step-up"),Map.of("password","bad","purpose","TRANSFER","targetId",p)),a),401);
        call(auth(body(post("/api/v2/auth/step-up"),Map.of("password","LongPassword123!","purpose","PROFILE","targetId",p)),a),400);
        call(auth(body(post("/api/v2/auth/step-up"),Map.of("password","LongPassword123!","purpose","TRANSFER","targetId",p)),b),404);
        String token=grant(a,p);call(execute(a,other,token,key()),403);call(execute(b,p,token,key()),404);
        call(execute(a,p,"bad",key()),403);call(execute(a,p,token,"bad-key"),400);
        call(body(post("/api/v2/transfers"),Map.of("previewId",p,"actionToken",token)),401);
        String reused=key();call(auth(post("/api/v2/accounts"),a).header("Idempotency-Key",reused),201);
        call(execute(a,p,token,reused),409);assertEquals("100.00",balance(a));
    }
    @Test void expiryAndLiveBalanceAndStatusAreRechecked()throws Exception{
        Customer a=customer(),b=customer();deposit(a,"100");
        String p=preview(a,b,"90").path("previewId").asText(),token=grant(a,p),k=key();
        legacy(a,b,"20");assertEquals("INSUFFICIENT_BALANCE",call(execute(a,p,token,k),409).path("code").asText());
        assertEquals(0,jdbc.queryForObject("SELECT COUNT(*) FROM transfer_records WHERE preview_id=?",Integer.class,p));
        deposit(a,"20");jdbc.update("UPDATE accounts SET status='BLOCKED' WHERE public_id=?",b.id());
        assertEquals("ACCOUNT_UNAVAILABLE",call(execute(a,p,token,k),409).path("code").asText());
        call(auth(body(post("/api/transfers"),Map.of("fromAccount",a.number(),"toAccount",b.number(),"amount","1")),a).header("Idempotency-Key",key()),409);
        jdbc.update("UPDATE accounts SET status='ACTIVE' WHERE public_id=?",b.id());
        call(execute(a,p,token,k),200);
        String exp=preview(a,b,"1").path("previewId").asText(),expToken=grant(a,exp);
        jdbc.update("UPDATE transfer_actions SET expires_at=TIMESTAMP '2000-01-01 00:00:00' WHERE token_hash=?",SecurityConfig.hash(expToken));
        assertEquals("ACTION_TOKEN_INVALID",call(execute(a,exp,expToken,key()),403).path("code").asText());
        jdbc.update("UPDATE transfer_previews SET expires_at=TIMESTAMP '2000-01-01 00:00:00' WHERE id=?",exp);
        assertEquals("PREVIEW_EXPIRED",call(execute(a,exp,expToken,key()),409).path("code").asText());
    }
    @Test void receiverAndPasswordAttemptsAreLimited()throws Exception{
        Customer a=customer(),b=customer();deposit(a,"10");String p=preview(a,b,"1").path("previewId").asText();
        for(int i=0;i<5;i++)call(auth(body(post("/api/v2/auth/step-up"),Map.of("password","bad","purpose","TRANSFER","targetId",p)),a),401);
        call(auth(body(post("/api/v2/auth/step-up"),Map.of("password","LongPassword123!","purpose","TRANSFER","targetId",p)),a),429);
        for(int i=0;i<30;i++)call(auth(body(post("/api/v2/transfers/receiver-validation"),Map.of("bankCode","LOCAL","accountNumber",b.number())),a),200);
        call(auth(body(post("/api/v2/transfers/receiver-validation"),Map.of("bankCode","LOCAL","accountNumber",b.number())),a),429);
    }
    @Test void failedRecordInsertRollsBackBothBalancesLedgerAndGrant()throws Exception{
        Customer a=customer(),b=customer();deposit(a,"100");String p=preview(a,b,"13.37").path("previewId").asText(),token=grant(a,p),k=key();
        int count=jdbc.queryForObject("SELECT COUNT(*) FROM ledger_entries",Integer.class);
        jdbc.execute("ALTER TABLE transfer_records ADD CONSTRAINT test_fail_record CHECK(amount <> 13.37)");
        try{call(execute(a,p,token,k),500);}finally{jdbc.execute("ALTER TABLE transfer_records DROP CONSTRAINT test_fail_record");}
        assertEquals("100.00",balance(a));assertEquals("0.00",balance(b));
        assertEquals(count,jdbc.queryForObject("SELECT COUNT(*) FROM ledger_entries",Integer.class));
        assertNull(jdbc.queryForObject("SELECT result_id FROM transfer_previews WHERE id=?",String.class,p));
        assertFalse(jdbc.queryForObject("SELECT consumed FROM transfer_actions WHERE token_hash=?",Boolean.class,SecurityConfig.hash(token)));
        assertEquals(0,jdbc.queryForObject("SELECT COUNT(*) FROM idempotency_records WHERE request_key=?",Integer.class,k));
        call(execute(a,p,token,k),200);assertEquals("86.63",balance(a));
    }
    @Test void concurrentSameKeyAndDifferentKeysMoveMoneyOnlyOnce()throws Exception{
        Customer a=customer(),b=customer();deposit(a,"100");
        for(boolean sameKey:List.of(true,false)){
            String p=preview(a,b,"10").path("previewId").asText(),token=grant(a,p),k=key();
            var pool=Executors.newFixedThreadPool(2);var start=new CountDownLatch(1);
            try{
                var f1=pool.submit(()->{start.await();return mvc.perform(execute(a,p,token,k)).andReturn().getResponse();});
                var f2=pool.submit(()->{start.await();return mvc.perform(execute(a,p,token,sameKey?k:key())).andReturn().getResponse();});
                start.countDown();var r1=f1.get(20,TimeUnit.SECONDS);var r2=f2.get(20,TimeUnit.SECONDS);
                if(sameKey){assertEquals(200,r1.getStatus());assertEquals(200,r2.getStatus());assertEquals(json.readTree(r1.getContentAsByteArray()),json.readTree(r2.getContentAsByteArray()));}
                else assertEquals(Set.of(200,409),Set.of(r1.getStatus(),r2.getStatus()));
                assertEquals(1,jdbc.queryForObject("SELECT COUNT(*) FROM transfer_records WHERE preview_id=?",Integer.class,p));
            }finally{pool.shutdownNow();}
        }
        assertEquals("80.00",balance(a));assertEquals("20.00",balance(b));
    }
    @Test void oppositeDirectionLegacyAndV2TransfersPreserveTotal()throws Exception{
        Customer a=customer(),b=customer();deposit(a,"100");deposit(b,"100");
        String p=preview(a,b,"30").path("previewId").asText(),token=grant(a,p);
        var pool=Executors.newFixedThreadPool(2);var start=new CountDownLatch(1);
        try{
            var f1=pool.submit(()->{start.await();call(execute(a,p,token,key()),200);return true;});
            var f2=pool.submit(()->{start.await();legacy(b,a,"20");return true;});
            start.countDown();assertTrue(f1.get(20,TimeUnit.SECONDS));assertTrue(f2.get(20,TimeUnit.SECONDS));
        }finally{pool.shutdownNow();}
        assertEquals("90.00",balance(a));assertEquals("110.00",balance(b));
    }
    @Test void resultPagesAreDateBoundPrivateAndExcludeLaterRecords()throws Exception{
        Customer a=customer(),b=customer();deposit(a,"100");
        for(int i=0;i<3;i++){
            String p=preview(a,b,"1").path("previewId").asText();var result=call(execute(a,p,grant(a,p),key()),200);
            jdbc.update("UPDATE transfer_records SET created_at=? WHERE public_id=?",java.sql.Timestamp.from(java.time.Instant.parse("2026-10-01T15:00:00Z")),result.path("transferId").asText());
        }
        var first=call(auth(get("/api/v2/transfers").param("from","2026-10-02").param("to","2026-10-02").param("size","2"),a),200);
        assertEquals(2,first.path("items").size());assertTrue(first.path("hasNext").asBoolean());String cursor=first.path("nextCursor").asText();
        String p=preview(a,b,"1").path("previewId").asText();var late=call(execute(a,p,grant(a,p),key()),200);
        jdbc.update("UPDATE transfer_records SET created_at=? WHERE public_id=?",java.sql.Timestamp.from(java.time.Instant.parse("2026-10-01T15:00:00Z")),late.path("transferId").asText());
        var second=call(auth(get("/api/v2/transfers").param("from","2026-10-02").param("to","2026-10-02").param("size","2").param("cursor",cursor),a),200);
        assertEquals(1,second.path("items").size());assertFalse(second.path("hasNext").asBoolean());
        assertNotEquals(first.path("items").get(1).path("transferId"),second.path("items").get(0).path("transferId"));
        call(auth(get("/api/v2/transfers").param("from","2026-10-02").param("to","2026-10-02").param("cursor",cursor),b),400);
        call(auth(get("/api/v2/transfers").param("from","2026-10-01").param("to","2026-10-02").param("cursor",cursor),a),400);
        call(auth(get("/api/v2/transfers").param("from","2026-10-02").param("to","2026-10-02").param("cursor",cursor+"x"),a),400);
        call(auth(get("/api/v2/transfers").param("to","+999999999-01-01"),a),400);
        call(auth(get("/api/v2/transfers").param("size","0"),a),400);
        call(auth(get("/api/v2/transfers").param("from","2024-01-01").param("to","2026-01-01"),a),400);
        assertEquals(0,call(auth(get("/api/v2/transfers").param("from","2026-10-01").param("to","2026-10-01"),a),200).path("items").size());
    }
}
