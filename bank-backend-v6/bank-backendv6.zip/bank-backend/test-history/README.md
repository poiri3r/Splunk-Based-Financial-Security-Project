# 이전 계약 테스트 보관

v5에서 실행했던 테스트 중 폐기된 HTTP 경로, 선택 휴대폰 가입, 종전 복구/PIN 계약에 종속된 테스트 원본입니다. Maven의 src/test에 포함하지 않습니다. 현재 회귀 테스트는 src/test/java/com/club/bank이며 교체 범위와 실행 결과는 docs/VALIDATION_V6.md를 확인하세요. 이전 테스트를 삭제한 것이 아니라 계약 변경의 추적을 위해 분리했습니다.
